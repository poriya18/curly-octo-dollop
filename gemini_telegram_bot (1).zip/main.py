import telebot
import requests

# توکن ربات تلگرام
bot = telebot.TeleBot("8378244750:AAGQXki3Rds85QOqqc7U2KJWwT3P3WOq-SE")

# کلید API جمنای
GEMINI_API_KEY = "AIzaSyDejr8pPItOCDllc7Q9N812Y354R2zEhY0"
GEMINI_API_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent"

def ask_gemini(question):
    headers = {
        "Content-Type": "application/json"
    }
    payload = {
        "contents": [
            {
                "parts": [
                    {"text": question}
                ]
            }
        ]
    }
    params = {
        "key": GEMINI_API_KEY
    }
    response = requests.post(GEMINI_API_URL, json=payload, headers=headers, params=params)
    if response.status_code == 200:
        try:
            return response.json()['candidates'][0]['content']['parts'][0]['text']
        except:
            return "❌ مشکلی در دریافت پاسخ از Gemini پیش آمد."
    elif response.status_code == 429:
        return "❌ محدودیت دسترسی به Gemini (خطای 429). لطفاً بعداً امتحان کنید."
    else:
        return f"❌ خطا: {response.status_code}"

@bot.message_handler(func=lambda message: True)
def handle_all_messages(message):
    user_message = message.text
    bot.send_chat_action(message.chat.id, 'typing')
    reply = ask_gemini(user_message)
    bot.reply_to(message, reply)

bot.infinity_polling()